package main

import (
	"errors"
	"fmt"
)

// Item represents a product in the inventory.
type Item struct {
	ID       int
	Name     string
	Quantity int
	Price    float64
}

// Inventory stores items in a slice.
type Inventory struct {
	Items []Item
}

// AddItem validates and adds a new item.
func (inv *Inventory) AddItem(item Item) error {
	if item.ID <= 0 || item.Name == "" || item.Quantity < 0 || item.Price < 0 {
		return errors.New("invalid item details")
	}

	for _, existing := range inv.Items {
		if existing.ID == item.ID {
			return errors.New("item already exists")
		}
	}

	inv.Items = append(inv.Items, item)
	return nil
}

// UpdateItem changes the quantity and price of an existing item.
func (inv *Inventory) UpdateItem(id, quantity int, price float64) error {
	if quantity < 0 || price < 0 {
		return errors.New("quantity and price cannot be negative")
	}

	for i := range inv.Items {
		if inv.Items[i].ID == id {
			inv.Items[i].Quantity = quantity
			inv.Items[i].Price = price
			return nil
		}
	}

	return errors.New("item not found")
}

// RemoveItem deletes an item by ID.
func (inv *Inventory) RemoveItem(id int) error {
	for i, item := range inv.Items {
		if item.ID == id {
			inv.Items = append(inv.Items[:i], inv.Items[i+1:]...)
			return nil
		}
	}

	return errors.New("item not found")
}

// Statistics contains a summary of the inventory.
type Statistics struct {
	ItemCount  int
	TotalValue float64
}

// CalculateStats calculates inventory statistics in a goroutine
// and sends the result through a channel.
func CalculateStats(items []Item) Statistics {
	result := make(chan Statistics)

	go func() {
		stats := Statistics{}

		for _, item := range items {
			stats.ItemCount++
			stats.TotalValue += float64(item.Quantity) * item.Price
		}

		result <- stats
	}()

	return <-result
}

func main() {
	inventory := Inventory{}

	// Add sample items.
	sampleItems := []Item{
		{ID: 1, Name: "Laptop", Quantity: 5, Price: 50000},
		{ID: 2, Name: "Mouse", Quantity: 10, Price: 500},
		{ID: 3, Name: "Keyboard", Quantity: 7, Price: 1200},
	}

	for _, item := range sampleItems {
		if err := inventory.AddItem(item); err != nil {
			fmt.Println("Add error:", err)
		}
	}

	fmt.Println("INVENTORY MANAGEMENT SYSTEM")
	fmt.Println("--------------------------------")
	for _, item := range inventory.Items {
		fmt.Printf("ID: %d | Name: %s | Quantity: %d | Price: Rs. %.2f\n",
			item.ID, item.Name, item.Quantity, item.Price)
	}

	fmt.Println("\nUpdating Laptop...")
	if err := inventory.UpdateItem(1, 8, 52000); err != nil {
		fmt.Println("Update error:", err)
	}

	fmt.Println("Removing Mouse...")
	if err := inventory.RemoveItem(2); err != nil {
		fmt.Println("Remove error:", err)
	}

	fmt.Println("\nFINAL INVENTORY")
	for _, item := range inventory.Items {
		fmt.Printf("%+v\n", item)
	}

	stats := CalculateStats(inventory.Items)
	fmt.Println("\nINVENTORY SUMMARY")
	fmt.Println("Total Items:", stats.ItemCount)
	fmt.Printf("Total Inventory Value: Rs. %.2f\n", stats.TotalValue)
}
