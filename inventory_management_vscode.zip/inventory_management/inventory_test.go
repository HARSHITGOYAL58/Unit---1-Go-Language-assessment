package main

import "testing"

func TestAddItem(t *testing.T) {
	inv := Inventory{}
	item := Item{ID: 1, Name: "Laptop", Quantity: 5, Price: 50000}

	if err := inv.AddItem(item); err != nil {
		t.Fatalf("AddItem returned an error: %v", err)
	}
	if len(inv.Items) != 1 {
		t.Fatalf("expected 1 item, got %d", len(inv.Items))
	}
}

func TestAddItemRejectsDuplicateID(t *testing.T) {
	inv := Inventory{}
	item := Item{ID: 1, Name: "Laptop", Quantity: 5, Price: 50000}

	if err := inv.AddItem(item); err != nil {
		t.Fatalf("first AddItem returned an error: %v", err)
	}
	if err := inv.AddItem(item); err == nil {
		t.Fatal("expected duplicate ID to return an error")
	}
}

func TestUpdateItem(t *testing.T) {
	inv := Inventory{}
	if err := inv.AddItem(Item{ID: 1, Name: "Laptop", Quantity: 5, Price: 50000}); err != nil {
		t.Fatal(err)
	}

	if err := inv.UpdateItem(1, 10, 55000); err != nil {
		t.Fatalf("UpdateItem returned an error: %v", err)
	}
	if inv.Items[0].Quantity != 10 || inv.Items[0].Price != 55000 {
		t.Fatalf("item was not updated correctly: %+v", inv.Items[0])
	}
}

func TestRemoveItem(t *testing.T) {
	inv := Inventory{}
	if err := inv.AddItem(Item{ID: 1, Name: "Laptop", Quantity: 5, Price: 50000}); err != nil {
		t.Fatal(err)
	}

	if err := inv.RemoveItem(1); err != nil {
		t.Fatalf("RemoveItem returned an error: %v", err)
	}
	if len(inv.Items) != 0 {
		t.Fatalf("expected empty inventory, got %d items", len(inv.Items))
	}
}

func TestCalculateStats(t *testing.T) {
	items := []Item{
		{ID: 1, Name: "Laptop", Quantity: 2, Price: 100},
		{ID: 2, Name: "Mouse", Quantity: 3, Price: 10},
	}

	stats := CalculateStats(items)
	if stats.ItemCount != 2 {
		t.Errorf("expected item count 2, got %d", stats.ItemCount)
	}
	if stats.TotalValue != 230 {
		t.Errorf("expected total value 230, got %.2f", stats.TotalValue)
	}
}
